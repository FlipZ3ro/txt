# Raydium CLMM

Raydium exposes a list of all the clmm pools and needed keys here <https://api.raydium.io/v2/ammV3/ammPools>.
