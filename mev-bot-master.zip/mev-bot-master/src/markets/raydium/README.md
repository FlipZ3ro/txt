# Raydium

Raydium exposes a list of all the pools and needed keys here <https://api.raydium.io/v2/sdk/liquidity/mainnet.json>.
I have no idea how often that data is updated.
More docs here <https://github.com/raydium-io/raydium-sdk/tree/master> - could also pull that data on startup with their sdk but had issues with that.
